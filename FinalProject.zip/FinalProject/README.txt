Link for project in Google Colab:

https://colab.research.google.com/drive/1qK_heDBRuHMRhlOFGpzKNFPu8__eO42S?usp=sharing

or

https://colab.research.google.com/drive/1UkgRpw8ycw6m3VxvCeYkntr95fwc2_rI#scrollTo=9b0fb6b7-6b86-48b6-85a5-faa031a0ff0c
